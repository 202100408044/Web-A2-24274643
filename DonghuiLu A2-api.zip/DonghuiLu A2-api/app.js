const express = require('express');
const bodyParser = require('body-parser');
const morgan = require('morgan');
// 解决跨域
const cors = require('cors');


// 引入数据库连接
const db = require('./crowdfunding_db');

const app = express();
const port = process.env.PORT || 3000;

// 解决跨域问题
app.use(cors());

app.use(bodyParser.json());
app.use(morgan('dev'));

app.get('/category', (req, res) => {

    db.query('SELECT * FROM category', (err, results) => {
        if (err) {
            return res.status(500).json({error: err.message});
        }
        res.json(results);
    });
});

app.get('/fundraiser', (req, res) => {

    db.query('SELECT f.*,c.name FROM fundraiser f INNER JOIN category c on f.category_id = c.category_id order by f.active DESC', (err, results) => {
        if (err) {
            return res.status(500).json({error: err.message});
        }
        res.json(results);
    });
});

app.get('/fundraiser/one/:id', (req, res) => {
    db.query('SELECT f.*,c.name FROM fundraiser f INNER JOIN category c on f.category_id = c.category_id where f.id = ?', [req.params.id], (err, results) => {
        if (err) {
            return res.status(500).json({error: err.message});
        }
        let resultData = results[0];
        // 处理活跃度
        let active = resultData.active + 1;

        const query = 'UPDATE fundraiser SET active = ? WHERE id = ?'; // 注意表名的单数形式
        db.query(query, [active, req.params.id], (err, updateResults) => {
            if (err) {
                return res.status(400).json({ error: err.message });
            }
            res.json(resultData); // 发送查询结果
        });
    });
});

// 多条件查询筹款活动
app.get('/fundraiser/search', (req, res) => {
    const { organizer, categoryId, city } = req.query;

    // 基础查询语句
    let query = 'SELECT * FROM fundraiser f INNER JOIN category c on f.category_id = c.category_id  WHERE 1=1';
    const params = [];

    // 动态添加条件
    if (organizer) {
        query += ' AND f.organizer LIKE ?';
        params.push(`%${organizer}%`);
    }
    if (categoryId) {
        query += ' AND f.category_id LIKE ?';
        params.push(`%${categoryId}%`);
    }
    if (city) {
        query += ' AND f.city LIKE ?';
        params.push(`%${city}%`);
    }

    query +=" ORDER BY f.active DESC"


    console.log(query)

    db.query(query, params, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(results);
    });
});


app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
